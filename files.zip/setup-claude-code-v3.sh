#!/bin/bash

# ============================================================
# 🚀 Setup Claude Code para TaskManager
# Solo configura el entorno, NO impone estructuras
# ============================================================

set -e

# Colores
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}"
echo "============================================================"
echo "🚀 Setup de Claude Code como Copiloto"
echo "============================================================"
echo -e "${NC}"

# ------------------------------------------------------------
# 1. Verificar requisitos
# ------------------------------------------------------------
echo -e "${YELLOW}📋 Verificando requisitos...${NC}"

command -v node &> /dev/null && echo -e "${GREEN}✓ Node.js${NC}" || { echo "Instala Node.js 18+"; exit 1; }
command -v npm &> /dev/null && echo -e "${GREEN}✓ npm${NC}"

if command -v claude &> /dev/null; then
    echo -e "${GREEN}✓ Claude Code CLI${NC}"
else
    echo -e "${YELLOW}Instalando Claude Code CLI...${NC}"
    npm install -g @anthropic-ai/claude-code
fi

echo ""

# ------------------------------------------------------------
# 2. Crear directorio de configuración
# ------------------------------------------------------------
echo -e "${YELLOW}📁 Configurando ~/.claude/...${NC}"
mkdir -p ~/.claude
echo -e "${GREEN}✓ Directorio creado${NC}"

# ------------------------------------------------------------
# 3. Crear settings.json
# ------------------------------------------------------------
cat > ~/.claude/settings.json << 'EOF'
{
  "permissions": {
    "allow": [
      "Read",
      "Bash(npm:*)",
      "Bash(npx:*)",
      "Bash(ng:*)",
      "Bash(nest:*)",
      "Bash(git:*)",
      "Bash(mysql:*)",
      "Bash(node:*)",
      "Bash(cat:*)",
      "Bash(ls:*)",
      "Bash(mkdir:*)"
    ],
    "deny": [
      "Bash(rm -rf *)",
      "Bash(sudo *)"
    ]
  },
  "autoEdits": "suggest",
  "autoUpdates": true
}
EOF
echo -e "${GREEN}✓ settings.json creado${NC}"

# ------------------------------------------------------------
# 4. Crear plantilla de MCP servers
# ------------------------------------------------------------
cat > ~/.claude/mcp_servers.json << 'EOF'
{
  "mcpServers": {
    "filesystem": {
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-filesystem", "RUTA_A_TU_PROYECTO"]
    },
    "mysql": {
      "command": "npx",
      "args": ["-y", "@benborber/mcp-server-mysql"],
      "env": {
        "MYSQL_HOST": "localhost",
        "MYSQL_PORT": "3306",
        "MYSQL_USER": "TU_USUARIO",
        "MYSQL_PASSWORD": "TU_PASSWORD",
        "MYSQL_DATABASE": "taskmanager_db"
      }
    },
    "github": {
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-github"],
      "env": {
        "GITHUB_PERSONAL_ACCESS_TOKEN": "TU_TOKEN_GITHUB"
      }
    },
    "memory": {
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-memory"]
    },
    "fetch": {
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-fetch"]
    },
    "sequential-thinking": {
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-sequential-thinking"]
    }
  }
}
EOF
echo -e "${GREEN}✓ mcp_servers.json creado (plantilla)${NC}"

echo ""

# ------------------------------------------------------------
# Instrucciones finales
# ------------------------------------------------------------
echo -e "${BLUE}"
echo "============================================================"
echo "✅ Configuración base completada"
echo "============================================================"
echo -e "${NC}"

echo -e "${YELLOW}📋 Próximos pasos:${NC}"
echo ""
echo "1. ${BLUE}Edita tus credenciales:${NC}"
echo "   vim ~/.claude/mcp_servers.json"
echo "   - Cambia RUTA_A_TU_PROYECTO"
echo "   - Agrega tu GITHUB_PERSONAL_ACCESS_TOKEN"
echo "   - Configura credenciales de MySQL"
echo ""
echo "2. ${BLUE}Copia CLAUDE.md a tu proyecto:${NC}"
echo "   cp CLAUDE-taskmanager-v3.md ~/tu-proyecto/CLAUDE.md"
echo ""
echo "3. ${BLUE}Inicia Claude Code:${NC}"
echo "   cd ~/tu-proyecto && claude"
echo ""
echo "4. ${BLUE}Verifica:${NC}"
echo "   > \"Claude, ¿puedes leer mi CLAUDE.md?\""
echo ""
echo -e "${GREEN}Recuerda: TÚ decides, Claude guía. 🚀${NC}"

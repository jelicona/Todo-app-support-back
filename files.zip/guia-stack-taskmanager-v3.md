# 🚀 Stack de Desarrollo con Claude Code para TaskManager

> **Filosofía**: Tú decides, Claude guía y corrige.

---

## 📋 Contenido

1. [El Problema que Resolvemos](#1-el-problema-que-resolvemos)
2. [Configuración del Entorno](#2-configuración-del-entorno)
3. [MCPs y Para Qué Sirven](#3-mcps-y-para-qué-sirven)
4. [Cómo Interactuar con Claude Code](#4-cómo-interactuar-con-claude-code)
5. [Consumo de Tokens](#5-consumo-de-tokens)
6. [Checklist de Implementación](#6-checklist-de-implementación)

---

## 1. El Problema que Resolvemos

### Lo que NO querías

```
TÚ: "Claude, crea el módulo de tasks"
CLAUDE: [genera 500 líneas de código]
TÚ: "Ok, aprobado"

RESULTADO: No aprendiste nada. Claude decidió todo.
```

### Lo que SÍ quieres

```
TÚ: "Quiero crear el módulo de tasks. ¿Qué opciones tengo?"
CLAUDE: "Hay varios enfoques: [explica 3 alternativas con pros/contras]"
TÚ: "Me gusta el segundo, voy a intentarlo"
[Tú escribes el código]
TÚ: "¿Qué tal quedó?"
CLAUDE: "Funciona, pero podrías mejorar X porque Y"

RESULTADO: TÚ decidiste, TÚ implementaste, aprendiste.
```

### El Rol del CLAUDE.md

El archivo `CLAUDE.md` en la raíz de tu proyecto le dice a Claude Code:
- Que TÚ eres quien decide
- Que él debe GUIAR, no imponer
- Que debe corregirte cuando te equivoques
- Dónde está tu documentación (Notion)
- Qué stack usas (pero no cómo estructurarlo)

---

## 2. Configuración del Entorno

### Estructura de Archivos

```
~/.claude/
├── settings.json         # Permisos y configuración global
└── mcp_servers.json      # Tus MCPs (MySQL, GitHub, etc.)

~/tu-proyecto/
├── CLAUDE.md             # ⭐ Instrucciones para Claude
└── ... (lo que tú decidas)
```

### Settings Global (~/.claude/settings.json)

```json
{
  "permissions": {
    "allow": [
      "Read",
      "Bash(npm:*)",
      "Bash(npx:*)",
      "Bash(ng:*)",
      "Bash(nest:*)",
      "Bash(git:*)",
      "Bash(mysql:*)",
      "Bash(node:*)"
    ],
    "deny": [
      "Bash(rm -rf *)",
      "Bash(sudo *)"
    ]
  },
  "autoEdits": "suggest",
  "autoUpdates": true
}
```

**Nota sobre `autoEdits: "suggest"`**: Claude te SUGIERE cambios, tú decides si aplicarlos. Esto es clave para mantener el control.

---

## 3. MCPs y Para Qué Sirven

### ¿Qué son los MCPs?

Son "sentidos adicionales" para Claude. Sin ellos, Claude no puede ver tu código, tu BD, o tu documentación. Con ellos, el contexto es automático.

### MCPs Recomendados para tu Proyecto

| MCP | Para qué lo usarás |
|-----|-------------------|
| **filesystem** | Claude ve tus archivos sin que expliques rutas |
| **mysql** | Claude puede ver tu esquema, ayudarte con queries |
| **github** | Claude busca cómo hacen las cosas en proyectos reales |
| **memory** | Claude recuerda decisiones entre sesiones |
| **fetch** | Claude lee documentación oficial actualizada |
| **sequential-thinking** | Para problemas complejos, razona paso a paso |

### Archivo de Configuración (~/.claude/mcp_servers.json)

```json
{
  "mcpServers": {
    "filesystem": {
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-filesystem", "/ruta/a/tu/proyecto"]
    },
    "mysql": {
      "command": "npx",
      "args": ["-y", "@benborber/mcp-server-mysql"],
      "env": {
        "MYSQL_HOST": "localhost",
        "MYSQL_PORT": "3306",
        "MYSQL_USER": "tu_usuario",
        "MYSQL_PASSWORD": "tu_password",
        "MYSQL_DATABASE": "taskmanager_db"
      }
    },
    "github": {
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-github"],
      "env": {
        "GITHUB_PERSONAL_ACCESS_TOKEN": "tu_token"
      }
    },
    "memory": {
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-memory"]
    },
    "fetch": {
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-fetch"]
    },
    "sequential-thinking": {
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-sequential-thinking"]
    }
  }
}
```

---

## 4. Cómo Interactuar con Claude Code

### El Flujo Contextual (lo que pedías)

Con filesystem MCP configurado:

```
1. Seleccionas código en VS Code
2. Ctrl+Shift+A (o el atajo que configures)
3. Preguntas: "¿Qué enfoque debería usar aquí?"
4. Claude YA SABE qué archivo es, qué línea, qué función
5. No tienes que explicar "mira el archivo en src/..."
```

### Tipos de Preguntas Efectivas

```
PARA EXPLORAR OPCIONES:
"¿Qué alternativas tengo para [X]?"
"¿Cómo se hace [X] en proyectos enterprise?"
"¿Cuáles son los pros y contras de [enfoque]?"

PARA VALIDAR TU DECISIÓN:
"Decidí hacer [X], ¿ves algún problema?"
"¿Este enfoque sigue [principio SOLID]?"
"¿Cómo se compara esto con las mejores prácticas?"

PARA REVISAR CÓDIGO:
[Seleccionar código] "¿Qué mejorarías aquí?"
[Seleccionar código] "/review"
"¿Este código es testeable?"

PARA APRENDER CONCEPTOS:
"Explícame [patrón/concepto] con una analogía"
"¿Cuándo usaría [patrón] vs [otro patrón]?"
"¿Por qué [X] es mejor que [Y] en este contexto?"
```

### Comandos Personalizados (definidos en tu CLAUDE.md)

| Comando | Claude hace... |
|---------|---------------|
| `/options [tema]` | Presenta alternativas para que elijas |
| `/review` | Analiza código seleccionado |
| `/compare` | Compara tu enfoque con industria |
| `/explain [X]` | Explica concepto con analogías |
| `/validate` | Valida tu decisión vs mejores prácticas |
| `/notion [tema]` | Consulta tu documentación |
| `/industry` | Busca ejemplos en repos open source |

---

## 5. Consumo de Tokens

### Tu Plan de $20 USD

| Aspecto | Detalle |
|---------|---------|
| Modelo | Claude 3.5 Sonnet (en Claude Code) |
| Límite aprox. | ~100 mensajes complejos/día |

### Cómo Optimizar

| Acción | Impacto |
|--------|---------|
| Pedir explicaciones (no código) | Bajo consumo |
| Seleccionar código específico | Bajo consumo |
| Pedir archivos completos | Alto consumo |
| Sesiones largas sin limpiar | Alto consumo |

### Tips Prácticos

```
✅ Sesiones de 30-45 min con objetivo claro
✅ Limpia contexto cuando cambies de tema: claude --new
✅ Selecciona solo el código relevante
✅ Pregunta conceptos antes de pedir código
✅ Usa /compact para respuestas cortas
```

---

## 6. Checklist de Implementación

### Paso 1: Instalar Claude Code (5 min)

```bash
npm install -g @anthropic-ai/claude-code
claude --version  # Verificar instalación
```

### Paso 2: Crear Configuración (~/.claude/) (10 min)

```bash
mkdir -p ~/.claude

# Crear settings.json (copiar el de arriba)
# Crear mcp_servers.json (copiar y editar credenciales)
```

### Paso 3: Configurar tu Proyecto (5 min)

```bash
cd ~/tu-proyecto

# Copiar CLAUDE-taskmanager-v3.md como CLAUDE.md
# (Descárgalo de los archivos que te di)
```

### Paso 4: Obtener Tokens Necesarios (10 min)

**GitHub Token:**
1. github.com/settings/tokens
2. Generate new token (classic)
3. Permisos: `repo` (read), `read:org`

**MySQL:**
- Asegúrate de tener tu BD corriendo
- Crea usuario con permisos de lectura

### Paso 5: Verificar (2 min)

```bash
cd ~/tu-proyecto
claude

# En el chat:
> "Claude, ¿puedes leer mi CLAUDE.md?"
> "¿Qué MCPs tienes disponibles?"
```

### Paso 6: Primera Sesión de Trabajo

```bash
# Ejemplo de flujo
> "Voy a comenzar a estructurar el backend. ¿Qué opciones tengo?"

# Claude te presenta alternativas
# TÚ eliges una
# TÚ implementas
# Pides revisión cuando quieras
```

---

## 📚 Recursos

### Documentación Oficial
- NestJS: https://docs.nestjs.com/
- Angular: https://angular.dev/
- TypeORM: https://typeorm.io/
- Socket.io: https://socket.io/docs/

### Tu Documentación (Notion)
- Proyecto: https://notion.so/a761e1794ef0428097ce24f75ab1b8de
- Plan de Trabajo: https://notion.so/2d11330f9f2081c6a7ede2667308de21

---

## 🎯 Recuerda

```
TÚ decides la arquitectura
TÚ decides los patrones
TÚ decides la estructura
TÚ escribes el código

Claude GUÍA con opciones
Claude COMPARA con industria
Claude CORRIGE errores
Claude EXPLICA conceptos
```

¡Listo para comenzar! 🚀
